from django.shortcuts import render

# Create your views here.
def suma(request):
    resultado  = None
    operacion = None
    if request.method == "POST":
        numero1 = int(request.POST.get("num1"))
        numero2 = int(request.POST.get("num2"))
        operacion = request.POST.get("operacion")
        if numero1 and numero2 :
            try:
                if operacion == 'suma':
                    resultado = int(numero1) + int(numero2)
                if operacion == 'resta':
                    resultado = int(numero1) - int(numero2)
                if operacion == 'multiplicacion':
                    resultado = int(numero1) * int(numero2)
                if operacion == 'division':
                    if numero2 != 0:
                        resultado = int(numero1) / int(numero2) 
                    else:
                        resultado = 'Operacion entre cero no permitida!!!!'
            except ValueError:
                resultado = 'Por favor ingresar numeros para operar'
    return render(request, "suma.html", {"resultado":resultado})