from django.shortcuts import render

# Create your views here.
def operacion(request):
    return render(request, "operacion.html")